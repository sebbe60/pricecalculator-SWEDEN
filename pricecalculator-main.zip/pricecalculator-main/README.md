price calculator in Agapi
